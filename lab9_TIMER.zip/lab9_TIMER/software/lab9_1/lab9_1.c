#include <stdio.h>
#include "system.h"
#include "altera_avalon_timer_regs.h"
#include "sys/alt_irq.h"

// Biến toàn cục, tăng lên 1 sau mỗi giây
unsigned int counter = 0;

// Trình xử lý ngắt của Timer
void Timer_IRQ_Handler(void* isr_context)
{
    // Tăng biến đếm và in ra console
    counter++;
    printf("%d seconds\n", counter);

    // Xóa bit ngắt của Timer
    IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_0_BASE, ALTERA_AVALON_TIMER_STATUS_TO_MSK);
}

// Hàm khởi tạo Timer
void Timer_Init(void)
{
    unsigned int period = 0;
    // Kiểm tra từng bit trong thanh ghi Status
    unsigned int status = IORD_ALTERA_AVALON_TIMER_STATUS(TIMER_0_BASE);
        printf("Status Register: 0x%08X\n", status);
        if (status & 0x01)
        	printf("  PE bit set (Period Expired)\n");
        if (status & 0x02)
        	printf("  RRDY bit set (Read Ready)\n");

    // Dừng Timer
    IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_0_BASE, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);

    // Xung nhịp của Timer là 50 MHz
    // Để đặt chu kỳ của Timer thành 1 giây, thanh ghi chu kỳ phải là (50000000-1)
    period = 4 - 1;
    IOWR_ALTERA_AVALON_TIMER_PERIODL(TIMER_0_BASE, (period & 0xFFFF));
    IOWR_ALTERA_AVALON_TIMER_PERIODH(TIMER_0_BASE, (period >> 16));

    // Cấu hình và bắt đầu Timer
    IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_0_BASE, ALTERA_AVALON_TIMER_CONTROL_CONT_MSK | // Chế độ đếm liên tục
                                     ALTERA_AVALON_TIMER_CONTROL_ITO_MSK | // Kích hoạt ngắt
                                     ALTERA_AVALON_TIMER_CONTROL_START_MSK); // Bắt đầu Timer
}

// Điểm vào chương trình chính
int main(void)
{
    // Cấu hình Timer
    Timer_Init();

    // Đăng ký trình xử lý ngắt của Timer
    alt_ic_isr_register(0, TIMER_0_IRQ, Timer_IRQ_Handler, (void*)0, (void*)0);

    while (1);
}
