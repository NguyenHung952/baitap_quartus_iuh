#include "sys/alt_stdio.h"
#include <stdio.h>
#include "system.h"
#include "altera_avalon_pio_regs.h" // Thư viện hỗ trợ đọc/ghi PIO

// Bảng mã LED 7 đoạn (Hex -> a-g)
const char led_segments[10] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};

// Hàm xuất số ra LED 7 đoạn
void display_digit(int digit, int pio_base) {
    IOWR_ALTERA_AVALON_PIO_DATA(pio_base, led_segments[digit]); // Gửi mã a-g
}

// Hàm hiển thị thời gian lên các LED 7 đoạn
void display_time(int hh, int mm, int ss) {
    // Giờ (hh)
    display_digit(hh / 10, PIO_LED_HH_TENS_BASE);   // Hàng chục giờ
    display_digit(hh % 10, PIO_LED_HH_UNITS_BASE); // Hàng đơn vị giờ

    // Phút (mm)
    display_digit(mm / 10, PIO_LED_MM_TENS_BASE);   // Hàng chục phút
    display_digit(mm % 10, PIO_LED_MM_UNITS_BASE); // Hàng đơn vị phút

    // Giây (ss)
    display_digit(ss / 10, PIO_LED_SS_TENS_BASE);   // Hàng chục giây
    display_digit(ss % 10, PIO_LED_SS_UNITS_BASE); // Hàng đơn vị giây
}

// Hàm delay (đơn giản)
void delay(int ms) {
    volatile int i = 0;
    while (i < ms * 1000) {
        i++;
    }
}

int main() {
    int hh = 0, mm = 0, ss = 0; // Giờ, phút, giây

    while (1) {
        // Hiển thị thời gian lên LED 7 đoạn
        display_time(hh, mm, ss);

        // Xuất thông tin thời gian ra Transcript
        printf("Time: %02d:%02d:%02d\n", hh, mm, ss);

        // Xuất trạng thái của các PIO ra Transcript
//        printf("PIO_LED_HH_TENS: 0x%02X\n", IORD_ALTERA_AVALON_PIO_DATA(PIO_LED_HH_TENS_BASE));
//        printf("PIO_LED_HH_UNITS: 0x%02X\n", IORD_ALTERA_AVALON_PIO_DATA(PIO_LED_HH_UNITS_BASE));
//        printf("PIO_LED_MM_TENS: 0x%02X\n", IORD_ALTERA_AVALON_PIO_DATA(PIO_LED_MM_TENS_BASE));
//        printf("PIO_LED_MM_UNITS: 0x%02X\n", IORD_ALTERA_AVALON_PIO_DATA(PIO_LED_MM_UNITS_BASE));
//        printf("PIO_LED_SS_TENS: 0x%02X\n", IORD_ALTERA_AVALON_PIO_DATA(PIO_LED_SS_TENS_BASE));
//        printf("PIO_LED_SS_UNITS: 0x%02X\n", IORD_ALTERA_AVALON_PIO_DATA(PIO_LED_SS_UNITS_BASE));



        // Cập nhật thời gian
        ss++;
        if (ss >= 60) {
            ss = 0;
            mm++;
        }
        if (mm >= 60) {
            mm = 0;
            hh++;
        }
        if (hh >= 24) {
            hh = 0;
        }
    }

    return 0;
}
